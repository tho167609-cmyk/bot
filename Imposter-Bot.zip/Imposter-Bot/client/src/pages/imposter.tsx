import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "framer-motion";
import { Terminal, Send, User, Image as ImageIcon, Cpu, ShieldAlert, Code, Link as LinkIcon } from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import { toast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertMessageSchema, type Message } from "@shared/schema";
import bgImage from "@assets/generated_images/dark_abstract_cybernetic_circuit_board_background_with_neon_accents.png";

const MOCK_LOGS = [
  "Initializing handshake protocol...",
  "Bypassing firewall...",
  "Access granted to node 0x8F...",
  "Injecting payload...",
  "Spoofing origin headers...",
];

export default function ImposterBot() {
  const [logs, setLogs] = useState<string[]>([]);
  const scrollRef = useRef<HTMLDivElement>(null);

  const { data: messages = [] } = useQuery<Message[]>({
    queryKey: ["/api/messages"],
  });

  const mutation = useMutation({
    mutationFn: async (values: any) => {
      const res = await apiRequest("POST", "/api/messages", values);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/messages"] });
      addLog("PAYLOAD DELIVERED TO TARGET SERVER");
      toast({
        title: "INJECTION SUCCESSFUL",
        description: "Message dispatched to Discord via Webhook.",
      });
      form.setValue("content", ""); 
    },
    onError: (error: any) => {
      addLog(`ERROR: ${error.message}`);
      toast({
        variant: "destructive",
        title: "INJECTION FAILED",
        description: error.message,
      });
    }
  });

  const form = useForm({
    resolver: zodResolver(insertMessageSchema),
    defaultValues: {
      username: "",
      avatarUrl: "",
      content: "",
      webhookUrl: "",
    },
  });

  const addLog = (log: string) => {
    setLogs((prev) => [...prev.slice(-10), `[${new Date().toLocaleTimeString()}] ${log}`]);
  };

  useEffect(() => {
    let delay = 0;
    MOCK_LOGS.forEach((log) => {
      setTimeout(() => addLog(log), delay);
      delay += Math.random() * 500 + 200;
    });
  }, []);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  const onSubmit = (values: any) => {
    addLog(`ENCRYPTING PAYLOAD: ${values.content.substring(0, 10)}...`);
    mutation.mutate(values);
  };

  return (
    <div 
      className="min-h-screen w-full bg-cover bg-center bg-no-repeat font-mono text-foreground flex items-center justify-center p-4 md:p-8"
      style={{ backgroundImage: `url(${bgImage})` }}
    >
      <div className="absolute inset-0 bg-background/90 backdrop-blur-sm" />

      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.5 }}
        className="relative z-10 w-full max-w-6xl grid grid-cols-1 lg:grid-cols-12 gap-6"
      >
        <div className="lg:col-span-12 flex items-center justify-between border-b border-primary/30 pb-4 mb-4">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 bg-primary/20 rounded flex items-center justify-center border border-primary animate-pulse shadow-[0_0_10px_rgba(0,255,0,0.5)]">
              <Cpu className="text-primary w-6 h-6" />
            </div>
            <div>
              <h1 className="text-3xl font-display font-bold tracking-wider text-primary text-shadow-neon">
                IMPOSTER_BOT
              </h1>
              <p className="text-xs text-muted-foreground tracking-[0.2em] uppercase">
                Secure Webhook Injection Interface // V2.0.0
              </p>
            </div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-xs text-destructive animate-pulse">
            <ShieldAlert className="w-4 h-4" />
            <span>EXTERNAL LINK ESTABLISHED</span>
          </div>
        </div>

        <Card className="lg:col-span-5 bg-card/50 border-primary/30 backdrop-blur-md shadow-2xl overflow-hidden">
          <CardHeader className="bg-primary/5 border-b border-primary/20">
            <CardTitle className="flex items-center gap-2 text-primary">
              <Terminal className="w-5 h-5" />
              <span>COMMAND_CENTER</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="webhookUrl"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-widest text-accent flex items-center gap-2">
                        <LinkIcon className="w-3 h-3" /> Discord Webhook URL
                      </FormLabel>
                      <FormControl>
                        <Input 
                          placeholder="https://discord.com/api/webhooks/..." 
                          {...field} 
                          className="bg-background/50 border-accent/30 focus:border-accent text-accent"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="username"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase tracking-widest text-primary/80 flex items-center gap-2">
                          <User className="w-3 h-3" /> Identity
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="e.g. Admin" 
                            {...field} 
                            className="bg-background/50 border-primary/30 text-primary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="avatarUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-xs uppercase tracking-widest text-secondary flex items-center gap-2">
                          <ImageIcon className="w-3 h-3" /> Avatar URL
                        </FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://..." 
                            {...field} 
                            className="bg-background/50 border-secondary/30 text-secondary"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="content"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="text-xs uppercase tracking-widest text-accent flex items-center gap-2">
                        <Code className="w-3 h-3" /> Payload Content
                      </FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="/say Accessing mainframe..." 
                          {...field} 
                          className="min-h-[100px] bg-background/50 border-accent/30 text-accent"
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button 
                  type="submit" 
                  disabled={mutation.isPending}
                  className="w-full bg-primary/20 hover:bg-primary/40 text-primary border border-primary font-display tracking-widest"
                >
                  {mutation.isPending ? "INJECTING..." : "EXECUTE_PAYLOAD"}
                </Button>
              </form>
            </Form>
            
            <div className="mt-6 border border-muted bg-black/80 rounded-sm p-3 h-32 font-mono text-xs overflow-hidden flex flex-col">
              <div 
                ref={scrollRef}
                className="flex-1 overflow-y-auto scrollbar-hide space-y-1"
              >
                {logs.map((log, i) => (
                  <div key={i} className="text-green-500/80">
                    <span className="text-primary mr-2 opacity-50">{">"}</span>
                    {log}
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="lg:col-span-7">
          <Card className="bg-zinc-900 border-zinc-800 shadow-2xl h-[600px] flex flex-col overflow-hidden">
            <CardHeader className="bg-zinc-950 border-b border-zinc-800 p-4">
              <CardTitle className="text-zinc-400 text-sm flex items-center gap-2">
                <span className="text-zinc-600">#</span> webhook-transmission-log
              </CardTitle>
            </CardHeader>
            <ScrollArea className="flex-1 p-6">
              <div className="space-y-6">
                {messages.length === 0 ? (
                  <div className="h-full flex flex-col items-center justify-center text-zinc-600 space-y-4 mt-20 opacity-50">
                    <p className="font-mono text-xs tracking-widest">AWAITING_SIGNAL</p>
                  </div>
                ) : (
                  <AnimatePresence mode="popLayout">
                    {messages.map((msg) => (
                      <motion.div
                        key={msg.id}
                        initial={{ opacity: 0, x: -20 }}
                        animate={{ opacity: 1, x: 0 }}
                        className="flex gap-4 p-2 rounded hover:bg-zinc-800/30 transition-colors"
                      >
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={msg.avatarUrl || undefined} />
                          <AvatarFallback className="bg-primary/20 text-primary">
                            {msg.username.substring(0, 2).toUpperCase()}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-semibold text-zinc-200 text-sm">{msg.username}</span>
                            <span className="bg-primary/20 text-primary text-[10px] px-1 rounded">BOT</span>
                            <span className="text-zinc-500 text-[10px] ml-auto">
                              {new Date(msg.createdAt).toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="text-zinc-300 text-sm mt-1">{msg.content}</p>
                        </div>
                      </motion.div>
                    ))}
                  </AnimatePresence>
                )}
              </div>
            </ScrollArea>
          </Card>
        </div>
      </motion.div>
    </div>
  );
}