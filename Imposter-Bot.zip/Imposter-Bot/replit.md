# Imposter Bot - Webhook Playground

## Overview

Imposter Bot is a Discord webhook message simulator with a cyberpunk/hacker-themed terminal interface. The application allows users to send custom messages through Discord webhooks by impersonating any username and avatar. It features a React frontend with a futuristic UI design and an Express backend that proxies messages to Discord's webhook API.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Routing**: Wouter (lightweight React router)
- **State Management**: TanStack React Query for server state and caching
- **UI Components**: shadcn/ui component library built on Radix UI primitives
- **Styling**: Tailwind CSS v4 with custom cyberpunk theme (neon green terminal aesthetic)
- **Form Handling**: React Hook Form with Zod validation
- **Animations**: Framer Motion for UI transitions
- **Build Tool**: Vite with custom plugins for Replit integration

### Backend Architecture
- **Runtime**: Node.js with Express.js
- **Language**: TypeScript (ESM modules)
- **API Pattern**: RESTful endpoints under `/api` prefix
- **Storage**: In-memory storage (MemStorage class) - designed to be swappable with database implementation
- **Schema Validation**: Zod with drizzle-zod for type-safe validation

### Data Flow
1. User submits webhook message form on frontend
2. React Query mutation sends POST to `/api/messages`
3. Backend validates request with Zod schema
4. Backend forwards message to Discord webhook API
5. Response stored in memory and returned to client
6. Frontend updates message history via query invalidation

### Database Schema
The application uses Drizzle ORM with PostgreSQL dialect configured, though currently running with in-memory storage:
- **messages table**: id, username, avatarUrl, content, webhookUrl, status, createdAt

### Build System
- Development: Vite dev server with HMR
- Production: Custom build script using esbuild for server bundling and Vite for client

## External Dependencies

### Third-Party APIs
- **Discord Webhook API**: Messages are sent via Discord's webhook endpoints (user-provided webhook URLs)

### Database
- **PostgreSQL**: Configured via Drizzle ORM (DATABASE_URL environment variable required for database mode)
- **Current Mode**: In-memory storage (MemStorage) for development/testing

### Key NPM Packages
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Database ORM with PostgreSQL support
- **express**: HTTP server framework
- **zod**: Runtime type validation
- **framer-motion**: Animation library
- **shadcn/ui ecosystem**: Radix UI primitives with Tailwind styling

### Replit-Specific Integrations
- **@replit/vite-plugin-runtime-error-modal**: Development error overlay
- **@replit/vite-plugin-cartographer**: Development tooling
- **@replit/vite-plugin-dev-banner**: Development environment indicator
- **vite-plugin-meta-images**: Custom plugin for OpenGraph image handling with Replit domains